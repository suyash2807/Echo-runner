import { useEffect, useRef, useCallback } from "react";
import { useEchoGame } from "../lib/stores/useEchoGame";
import { useAudio } from "../lib/stores/useAudio";
import { useGameLoop } from "../hooks/use-game-loop";

interface Player {
  x: number;
  y: number;
  width: number;
  height: number;
  speed: number;
}

interface Echo {
  x: number;
  y: number;
  width: number;
  height: number;
  id: number;
  createdAt: number; // timestamp when echo was created
}

interface PowerUp {
  x: number;
  y: number;
  width: number;
  height: number;
  type: 'shield' | 'speed' | 'clear';
  id: number;
  createdAt: number;
}

export default function GameCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const playerRef = useRef<Player>({ x: 0, y: 0, width: 20, height: 20, speed: 2 });
  const echoesRef = useRef<Echo[]>([]);
  const lastEchoTimeRef = useRef(0);
  const echoIdRef = useRef(0);
  const keysRef = useRef({ left: false, right: false });
  const powerUpsRef = useRef<PowerUp[]>([]);
  const lastPowerUpTimeRef = useRef(0);
  const powerUpIdRef = useRef(0);
  const playerStateRef = useRef({
    hasShield: false,
    shieldExpiry: 0,
    speedBoost: false,
    speedExpiry: 0
  });
  
  const { gameState, score, endGame, incrementScore, currentSkin, skins } = useEchoGame();
  const { playHit } = useAudio();

  // Initialize player position
  const initializeGame = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    playerRef.current = {
      x: canvas.width / 2 - 10,
      y: canvas.height - 50,
      width: 20,
      height: 20,
      speed: 16
    };
    
    // Clear all echoes when starting new game
    echoesRef.current = [];
    lastEchoTimeRef.current = Date.now(); // Set to current time to prevent immediate echo creation
    echoIdRef.current = 0;
    
    // Clear power-ups and reset player state
    powerUpsRef.current = [];
    lastPowerUpTimeRef.current = Date.now();
    powerUpIdRef.current = 0;
    playerStateRef.current = {
      hasShield: false,
      shieldExpiry: 0,
      speedBoost: false,
      speedExpiry: 0
    };
    
    // Reset key states to prevent movement from previous game
    keysRef.current = {
      left: false,
      right: false
    };
  }, []);

  // Handle keyboard input
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      switch (event.code) {
        case 'ArrowLeft':
        case 'KeyA':
          keysRef.current.left = true;
          event.preventDefault();
          break;
        case 'ArrowRight':
        case 'KeyD':
          keysRef.current.right = true;
          event.preventDefault();
          break;
      }
    };

    const handleKeyUp = (event: KeyboardEvent) => {
      switch (event.code) {
        case 'ArrowLeft':
        case 'KeyA':
          keysRef.current.left = false;
          event.preventDefault();
          break;
        case 'ArrowRight':
        case 'KeyD':
          keysRef.current.right = false;
          event.preventDefault();
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  // Collision detection with small buffer for turning
  const checkCollision = useCallback((player: Player, echo: Echo): boolean => {
    const buffer = 3; // Small buffer to prevent collision during turns
    return player.x < echo.x + echo.width - buffer &&
           player.x + player.width > echo.x + buffer &&
           player.y < echo.y + echo.height - buffer &&
           player.y + player.height > echo.y + buffer;
  }, []);

  // Game update function
  const updateGame = useCallback((deltaTime: number) => {
    if (gameState !== 'playing') return;
    
    const canvas = canvasRef.current;
    if (!canvas) return;

    const player = playerRef.current;
    const echoes = echoesRef.current;
    const powerUps = powerUpsRef.current;
    const playerState = playerStateRef.current;
    const now = Date.now();
    
    // Get current skin colors
    const activeSkin = skins.find(s => s.id === currentSkin) || skins[0];

    // Update power-up effects
    if (playerState.hasShield && now > playerState.shieldExpiry) {
      playerState.hasShield = false;
    }
    if (playerState.speedBoost && now > playerState.speedExpiry) {
      playerState.speedBoost = false;
    }

    // Update player movement (horizontal speed is half of vertical speed)
    const baseHorizontalSpeed = player.speed / 2;
    const horizontalSpeed = playerState.speedBoost ? baseHorizontalSpeed * 1.5 : baseHorizontalSpeed;
    if (keysRef.current.left && player.x > 0) {
      player.x -= horizontalSpeed;
    }
    if (keysRef.current.right && player.x < canvas.width - player.width) {
      player.x += horizontalSpeed;
    }

    // Auto-move player upward
    player.y -= 8;

    // Wrap player vertically when reaching top
    if (player.y < -player.height) {
      player.y = canvas.height;
    }

    // Create power-ups occasionally
    const powerUpInterval = 5000; // Every 5 seconds
    if (now - lastPowerUpTimeRef.current > powerUpInterval) {
      const types: ('shield' | 'speed' | 'clear')[] = ['shield', 'speed', 'clear'];
      const randomType = types[Math.floor(Math.random() * types.length)];
      powerUps.push({
        x: Math.random() * (canvas.width - 30),
        y: -30,
        width: 25,
        height: 25,
        type: randomType,
        id: powerUpIdRef.current++,
        createdAt: now
      });
      lastPowerUpTimeRef.current = now;
    }

    // Update power-up positions
    for (let i = powerUps.length - 1; i >= 0; i--) {
      const powerUp = powerUps[i];
      powerUp.y += 6; // Power-ups fall down
      
      // Remove power-ups that are off screen
      if (powerUp.y > canvas.height) {
        powerUps.splice(i, 1);
      }
    }

    // Check power-up collection
    for (let i = powerUps.length - 1; i >= 0; i--) {
      const powerUp = powerUps[i];
      if (checkCollision(player, powerUp)) {
        // Activate power-up effect
        switch (powerUp.type) {
          case 'shield':
            playerState.hasShield = true;
            playerState.shieldExpiry = now + 3000; // 3 seconds
            break;
          case 'speed':
            playerState.speedBoost = true;
            playerState.speedExpiry = now + 4000; // 4 seconds
            break;
          case 'clear':
            echoesRef.current = []; // Clear all echoes
            break;
        }
        powerUps.splice(i, 1); // Remove collected power-up
      }
    }

    // Create echo trail (but not immediately when game starts)
    const echoInterval = 50; // Balanced echo creation for good density
    
    // Start creating echoes after brief delay  
    if (now - lastEchoTimeRef.current > echoInterval && now - lastEchoTimeRef.current > 300) {
      echoes.push({
        x: player.x,
        y: player.y,
        width: player.width,
        height: player.height,
        id: echoIdRef.current++,
        createdAt: now
      });
      lastEchoTimeRef.current = now;
    }

    // Remove old echoes that are older than 9 seconds
    const echoLifetime = 9000; // 9 seconds in milliseconds
    for (let i = echoes.length - 1; i >= 0; i--) {
      if (now - echoes[i].createdAt > echoLifetime) {
        echoes.splice(i, 1);
      }
    }

    // Check collisions only with echoes that are older than the current position
    if (echoes.length > 0 && !playerState.hasShield) {
      for (const echo of echoes) {
        // Only check collision with echoes that are at least 250ms old (more time for turns)
        if (now - echo.createdAt > 250 && checkCollision(player, echo)) {
          console.log("COLLISION! Player at:", player.x, player.y, "Echo at:", echo.x, echo.y);
          playHit();
          endGame();
          return;
        }
      }
    }

    // Increment score
    incrementScore();
  }, [gameState, checkCollision, playHit, endGame, incrementScore]);

  // Render function
  const render = useCallback(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;

    // Clear canvas
    ctx.fillStyle = '#000011';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    if (gameState !== 'playing') return;

    const player = playerRef.current;
    const echoes = echoesRef.current;
    const powerUps = powerUpsRef.current;
    const playerState = playerStateRef.current;
    const now = Date.now();

    // Draw background grid
    ctx.strokeStyle = '#1a1a2e';
    ctx.lineWidth = 1;
    for (let x = 0; x < canvas.width; x += 40) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, canvas.height);
      ctx.stroke();
    }
    for (let y = 0; y < canvas.height; y += 40) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(canvas.width, y);
      ctx.stroke();
    }

    // Draw echoes with fading effect
    const echoLifetime = 10000; // 10 seconds
    for (const echo of echoes) {
      const age = now - echo.createdAt;
      const ageRatio = Math.max(0, 1 - (age / echoLifetime)); // 1 = new, 0 = old
      
      // Make echoes stay bright longer, then fade slowly
      let alpha;
      if (ageRatio > 0.7) {
        alpha = 1; // Stay fully bright for first 30% of lifetime
      } else {
        alpha = ageRatio / 0.7; // Fade gradually in last 70% of lifetime
      }
      
      // Use current skin's echo color
      const activeSkin = skins.find(s => s.id === currentSkin) || skins[0];
      const echoColor = activeSkin.echoColor;
      const hexToRgb = (hex: string) => {
        const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
        return result ? {
          r: parseInt(result[1], 16),
          g: parseInt(result[2], 16),
          b: parseInt(result[3], 16)
        } : { r: 255, g: 51, b: 102 };
      };
      const rgb = hexToRgb(echoColor);
      
      ctx.fillStyle = `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, ${alpha})`;
      ctx.shadowColor = `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, ${alpha * 0.5})`;
      ctx.shadowBlur = 10 * alpha;
      
      ctx.fillRect(echo.x, echo.y, echo.width, echo.height);
    }

    // Draw power-ups
    for (const powerUp of powerUps) {
      let color, symbol;
      switch (powerUp.type) {
        case 'shield':
          color = '#4169E1'; // Blue
          symbol = '🛡️';
          break;
        case 'speed':
          color = '#FFD700'; // Gold
          symbol = '⚡';
          break;
        case 'clear':
          color = '#32CD32'; // Green
          symbol = '🧹';
          break;
      }
      
      ctx.fillStyle = color;
      ctx.shadowColor = color;
      ctx.shadowBlur = 10;
      ctx.fillRect(powerUp.x, powerUp.y, powerUp.width, powerUp.height);
      
      // Draw symbol in center
      ctx.font = '16px Arial';
      ctx.textAlign = 'center';
      ctx.fillStyle = 'white';
      ctx.shadowBlur = 0;
      ctx.fillText(symbol, powerUp.x + powerUp.width/2, powerUp.y + powerUp.height/2 + 5);
    }

    // Draw player with shield effect if active
    if (playerState.hasShield) {
      // Draw shield glow
      ctx.fillStyle = 'rgba(65, 105, 225, 0.3)';
      ctx.shadowColor = '#4169E1';
      ctx.shadowBlur = 20;
      ctx.fillRect(player.x - 5, player.y - 5, player.width + 10, player.height + 10);
    }
    
    // Use current skin's player color, but override with gold if speed boost is active
    const activeSkin = skins.find(s => s.id === currentSkin) || skins[0];
    const playerColor = playerState.speedBoost ? '#FFD700' : activeSkin.playerColor;
    
    ctx.fillStyle = playerColor;
    ctx.shadowColor = playerColor;
    ctx.shadowBlur = 15;
    ctx.fillRect(player.x, player.y, player.width, player.height);

    // Draw power-up status indicators
    ctx.fillStyle = 'white';
    ctx.font = '14px Arial';
    ctx.textAlign = 'left';
    ctx.shadowBlur = 0;
    
    let statusY = 30;
    if (playerState.hasShield) {
      const remaining = Math.ceil((playerState.shieldExpiry - now) / 1000);
      ctx.fillText(`🛡️ Shield: ${remaining}s`, 10, statusY);
      statusY += 20;
    }
    if (playerState.speedBoost) {
      const remaining = Math.ceil((playerState.speedExpiry - now) / 1000);
      ctx.fillText(`⚡ Speed: ${remaining}s`, 10, statusY);
    }

    // Reset shadow
    ctx.shadowBlur = 0;
  }, [gameState]);

  // Use game loop
  useGameLoop(updateGame, render, gameState === 'playing');

  // Initialize game when state changes
  useEffect(() => {
    if (gameState === 'playing') {
      initializeGame();
    }
  }, [gameState, initializeGame]);

  // Handle canvas resize
  useEffect(() => {
    const handleResize = () => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      
      // Reinitialize player position
      if (gameState === 'playing') {
        initializeGame();
      }
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [gameState, initializeGame]);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full"
      style={{ touchAction: 'none' }}
    />
  );
}
