import { useEffect, useRef } from "react";
import { useEchoGame } from "../lib/stores/useEchoGame";
import { useAudio } from "../lib/stores/useAudio";
import GameCanvas from "./GameCanvas";
import GameUI from "./GameUI";
import MobileControls from "./MobileControls";
import { useIsMobile } from "../hooks/use-is-mobile";

export default function EchoRunner() {
  const { gameState, startGame, restartGame } = useEchoGame();
  const { setHitSound } = useAudio();
  const isMobile = useIsMobile();
  const audioInitRef = useRef(false);

  // Initialize audio
  useEffect(() => {
    if (!audioInitRef.current) {
      audioInitRef.current = true;
      
      // Load hit sound
      const hitAudio = new Audio('/sounds/hit.mp3');
      hitAudio.preload = 'auto';
      setHitSound(hitAudio);
    }
  }, [setHitSound]);

  // Handle keyboard input
  useEffect(() => {
    const handleKeyPress = (event: KeyboardEvent) => {
      if (gameState === 'menu') {
        if (event.code === 'Space' || event.code === 'Enter') {
          startGame();
        }
      } else if (gameState === 'gameOver') {
        if (event.code === 'Space' || event.code === 'Enter') {
          restartGame();
        }
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [gameState, startGame, restartGame]);

  return (
    <div className="w-full h-full relative bg-black overflow-hidden">
      {/* Game Canvas */}
      <GameCanvas />
      
      {/* Game UI Overlay */}
      <GameUI />
      
      {/* Mobile Controls - Show during gameplay */}
      {gameState === 'playing' && <MobileControls />}
      
      {/* Background glow effect */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-b from-purple-900/20 via-transparent to-blue-900/20" />
      </div>
    </div>
  );
}
