import { useEchoGame } from "../lib/stores/useEchoGame";
import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { ArrowLeft, Coins, ShoppingCart, Check } from "lucide-react";

export default function Store() {
  const { 
    coins, 
    skins, 
    currentSkin, 
    closeStore, 
    buySkin, 
    selectSkin 
  } = useEchoGame();

  const handleBuy = (skinId: string) => {
    const success = buySkin(skinId);
    if (success) {
      selectSkin(skinId);
    }
  };

  return (
    <div className="absolute inset-0 flex items-center justify-center z-10">
      <Card className="w-full max-w-2xl mx-4 bg-black/90 border-cyan-500/50 backdrop-blur-sm">
        <CardContent className="p-6">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <ShoppingCart className="w-6 h-6 text-cyan-400" />
              <h1 className="text-2xl font-bold text-cyan-400">SKIN STORE</h1>
            </div>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 bg-yellow-900/30 rounded-lg px-3 py-2 border border-yellow-500/30">
                <Coins className="w-4 h-4 text-yellow-400" />
                <span className="text-yellow-400 font-bold">{coins}</span>
              </div>
              <Button
                onClick={closeStore}
                variant="outline"
                size="sm"
                className="border-cyan-500/50 text-cyan-400 hover:bg-cyan-500/10"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
            </div>
          </div>

          {/* Skins Grid */}
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {skins.map((skin) => (
              <div
                key={skin.id}
                className={`relative p-4 rounded-lg border-2 transition-all duration-200 ${
                  currentSkin === skin.id
                    ? 'border-cyan-400 bg-cyan-900/20'
                    : skin.unlocked
                    ? 'border-gray-600 bg-gray-900/30 hover:border-gray-400'
                    : 'border-gray-700 bg-gray-800/30'
                }`}
              >
                {/* Current skin indicator */}
                {currentSkin === skin.id && (
                  <div className="absolute top-2 right-2">
                    <Check className="w-5 h-5 text-cyan-400" />
                  </div>
                )}

                {/* Skin preview */}
                <div className="flex flex-col items-center mb-3">
                  <div className="flex gap-2 mb-2">
                    {/* Player preview */}
                    <div 
                      className="w-6 h-6 rounded border border-white/20"
                      style={{ backgroundColor: skin.playerColor }}
                    />
                    {/* Echo preview */}
                    <div 
                      className="w-6 h-6 rounded border border-white/20 opacity-70"
                      style={{ backgroundColor: skin.echoColor }}
                    />
                  </div>
                  <h3 className="text-white font-semibold text-sm text-center">
                    {skin.name}
                  </h3>
                </div>

                {/* Action button */}
                <div className="w-full">
                  {!skin.unlocked ? (
                    <Button
                      onClick={() => handleBuy(skin.id)}
                      disabled={coins < skin.price}
                      className={`w-full text-xs py-2 ${
                        coins >= skin.price
                          ? 'bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500 text-white'
                          : 'bg-gray-700 text-gray-400 cursor-not-allowed'
                      }`}
                    >
                      <Coins className="w-3 h-3 mr-1" />
                      {skin.price}
                    </Button>
                  ) : currentSkin === skin.id ? (
                    <div className="w-full py-2 text-xs text-center text-cyan-400 font-semibold border border-cyan-400/50 rounded-md">
                      EQUIPPED
                    </div>
                  ) : (
                    <Button
                      onClick={() => selectSkin(skin.id)}
                      className="w-full text-xs py-2 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white"
                    >
                      EQUIP
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Info */}
          <div className="mt-6 p-3 bg-blue-900/20 rounded-lg border border-blue-500/30">
            <p className="text-blue-200 text-xs text-center">
              💰 Earn coins by playing! Get 1 coin for every 10 points scored.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}