import { useEchoGame } from "../lib/stores/useEchoGame";
import { useAudio } from "../lib/stores/useAudio";
import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { Volume2, VolumeX, Play, RotateCcw, ShoppingCart, Coins } from "lucide-react";
import Store from "./Store";

export default function GameUI() {
  const { gameState, score, highScore, coins, startGame, restartGame, openStore } = useEchoGame();
  const { isMuted, toggleMute } = useAudio();
  
  console.log("GameUI render - Current game state:", gameState);
  
  // Test button to verify state changes
  const testStateChange = () => {
    console.log("Test: manually setting state to playing");
    // This is just for testing
  };

  if (gameState === 'menu') {
    return (
      <div className="absolute inset-0 flex items-center justify-center z-10">
        <Card className="w-full max-w-md mx-4 bg-black/80 border-cyan-500/50 backdrop-blur-sm">
          <CardContent className="p-6 text-center">
            {/* Title */}
            <div className="mb-6">
              <h1 className="text-3xl font-bold text-cyan-400 mb-2 tracking-wider">
                ECHO RUNNER
              </h1>
              <div className="w-20 h-1 bg-gradient-to-r from-cyan-400 to-purple-500 mx-auto mb-3" />
              <p className="text-cyan-200 text-xs">
                Avoid your own echoes and survive as long as possible
              </p>
            </div>

            {/* Stats */}
            <div className="mb-4 flex gap-2">
              {highScore > 0 && (
                <div className="flex-1 p-2 bg-purple-900/30 rounded-lg border border-purple-500/30">
                  <p className="text-purple-300 text-xs">High Score</p>
                  <p className="text-purple-400 text-lg font-bold">{highScore.toLocaleString()}</p>
                </div>
              )}
              <div className="flex-1 p-2 bg-yellow-900/30 rounded-lg border border-yellow-500/30">
                <p className="text-yellow-300 text-xs">Coins</p>
                <p className="text-yellow-400 text-lg font-bold">{coins}</p>
              </div>
            </div>

            {/* Instructions */}
            <div className="mb-6 text-left">
              <h3 className="text-cyan-300 font-semibold mb-2 text-sm">How to Play:</h3>
              <ul className="text-cyan-200 text-xs space-y-0.5">
                <li>• Use ← → arrow keys to move left/right</li>
                <li>• Avoid red echoes, collect power-ups!</li>
              </ul>
              
              {/* Power-ups explanation */}
              <div className="mt-3 p-2 bg-gradient-to-r from-blue-900/30 to-purple-900/30 rounded-lg border border-blue-500/30">
                <h4 className="text-blue-300 font-semibold mb-1 text-xs">Power-ups:</h4>
                <div className="text-xs space-y-0.5">
                  <div className="flex items-center gap-1">
                    <span>🛡️⚡🧹</span>
                    <span className="text-gray-300">Shield, Speed, Clear</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Start Button */}
            <button
              type="button"
              onClick={() => {
                console.log("Button clicked, calling startGame");
                startGame();
              }}
              className="w-full bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 text-white font-bold py-3 px-6 rounded-lg mb-4 transition-all duration-200 transform hover:scale-105 flex items-center justify-center cursor-pointer"
            >
              <Play className="w-5 h-5 mr-2" />
              START GAME
            </button>

            {/* Controls */}
            <div className="flex justify-center gap-2">
              <Button
                onClick={openStore}
                variant="outline"
                size="sm"
                className="border-green-500/50 text-green-400 hover:bg-green-500/10"
              >
                <ShoppingCart className="w-4 h-4 mr-1" />
                Store
              </Button>
              <Button
                onClick={toggleMute}
                variant="outline"
                size="sm"
                className="border-cyan-500/50 text-cyan-400 hover:bg-cyan-500/10"
              >
                {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (gameState === 'store') {
    return <Store />;
  }

  if (gameState === 'playing') {
    return (
      <div className="absolute top-0 left-0 right-0 z-10 p-4">
        <div className="flex justify-between items-start">
          {/* Score */}
          <div className="bg-black/60 backdrop-blur-sm rounded-lg p-3 border border-cyan-500/30">
            <p className="text-cyan-400 text-sm">Score</p>
            <p className="text-white text-xl font-bold">{score.toLocaleString()}</p>
          </div>



          {/* Mute Button */}
          <Button
            onClick={toggleMute}
            variant="outline"
            size="sm"
            className="bg-black/60 backdrop-blur-sm border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/10"
          >
            {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </Button>
        </div>
      </div>
    );
  }

  if (gameState === 'gameOver') {
    return (
      <div className="absolute inset-0 flex items-center justify-center z-10">
        <Card className="w-full max-w-md mx-4 bg-black/80 border-red-500/50 backdrop-blur-sm">
          <CardContent className="p-8 text-center">
            {/* Game Over Title */}
            <div className="mb-6">
              <h2 className="text-3xl font-bold text-red-400 mb-2">GAME OVER</h2>
              <div className="w-20 h-1 bg-gradient-to-r from-red-400 to-orange-500 mx-auto" />
            </div>

            {/* Score Display */}
            <div className="mb-6">
              <p className="text-gray-300 text-sm mb-1">Final Score</p>
              <p className="text-white text-3xl font-bold mb-4">{score.toLocaleString()}</p>
              
              {Math.floor(score / 10) > 0 && (
                <div className="mb-3 flex items-center justify-center gap-2 text-yellow-400">
                  <Coins className="w-4 h-4" />
                  <span className="font-bold">+{Math.floor(score / 10)} coins earned!</span>
                </div>
              )}
              
              {score === highScore && score > 0 && (
                <div className="bg-yellow-500/20 border border-yellow-500/50 rounded-lg p-2 mb-4">
                  <p className="text-yellow-400 text-sm font-semibold">🏆 NEW HIGH SCORE!</p>
                </div>
              )}
              
              <p className="text-gray-400 text-sm">
                High Score: {highScore.toLocaleString()}
              </p>
            </div>

            {/* Restart Button */}
            <Button
              onClick={restartGame}
              className="w-full bg-gradient-to-r from-green-500 to-blue-600 hover:from-green-400 hover:to-blue-500 text-white font-bold py-3 mb-4 transition-all duration-200 transform hover:scale-105"
            >
              <RotateCcw className="w-5 h-5 mr-2" />
              PLAY AGAIN
            </Button>

            {/* Controls hint */}
            <p className="text-gray-400 text-xs">
              Press SPACE or ENTER to restart
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return null;
}
