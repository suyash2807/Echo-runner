import { useCallback, useRef } from "react";
import { Button } from "./ui/button";
import { ChevronLeft, ChevronRight } from "lucide-react";

export default function MobileControls() {
  const leftPressedRef = useRef(false);
  const rightPressedRef = useRef(false);

  const simulateKeyEvent = useCallback((key: string, isDown: boolean) => {
    const event = new KeyboardEvent(isDown ? 'keydown' : 'keyup', {
      code: key,
      key: key,
      bubbles: true
    });
    window.dispatchEvent(event);
  }, []);

  const handleLeftPress = useCallback(() => {
    if (!leftPressedRef.current) {
      leftPressedRef.current = true;
      simulateKeyEvent('ArrowLeft', true);
    }
  }, [simulateKeyEvent]);

  const handleLeftRelease = useCallback(() => {
    if (leftPressedRef.current) {
      leftPressedRef.current = false;
      simulateKeyEvent('ArrowLeft', false);
    }
  }, [simulateKeyEvent]);

  const handleRightPress = useCallback(() => {
    if (!rightPressedRef.current) {
      rightPressedRef.current = true;
      simulateKeyEvent('ArrowRight', true);
    }
  }, [simulateKeyEvent]);

  const handleRightRelease = useCallback(() => {
    if (rightPressedRef.current) {
      rightPressedRef.current = false;
      simulateKeyEvent('ArrowRight', false);
    }
  }, [simulateKeyEvent]);

  return (
    <div className="absolute bottom-0 left-0 right-0 z-20 p-4">
      <div className="flex justify-between max-w-md mx-auto">
        {/* Left Control */}
        <Button
          variant="outline"
          size="lg"
          className="w-20 h-20 rounded-full bg-black/60 border-cyan-500/50 text-cyan-400 hover:bg-cyan-500/20 active:bg-cyan-500/30 backdrop-blur-sm touch-manipulation"
          onTouchStart={(e) => {
            e.preventDefault();
            handleLeftPress();
          }}
          onTouchEnd={(e) => {
            e.preventDefault();
            handleLeftRelease();
          }}
          onTouchCancel={(e) => {
            e.preventDefault();
            handleLeftRelease();
          }}
          onMouseDown={(e) => {
            e.preventDefault();
            handleLeftPress();
          }}
          onMouseUp={(e) => {
            e.preventDefault();
            handleLeftRelease();
          }}
          onMouseLeave={(e) => {
            e.preventDefault();
            handleLeftRelease();
          }}
        >
          <ChevronLeft className="w-8 h-8" />
        </Button>

        {/* Right Control */}
        <Button
          variant="outline"
          size="lg"
          className="w-20 h-20 rounded-full bg-black/60 border-cyan-500/50 text-cyan-400 hover:bg-cyan-500/20 active:bg-cyan-500/30 backdrop-blur-sm touch-manipulation"
          onTouchStart={(e) => {
            e.preventDefault();
            handleRightPress();
          }}
          onTouchEnd={(e) => {
            e.preventDefault();
            handleRightRelease();
          }}
          onTouchCancel={(e) => {
            e.preventDefault();
            handleRightRelease();
          }}
          onMouseDown={(e) => {
            e.preventDefault();
            handleRightPress();
          }}
          onMouseUp={(e) => {
            e.preventDefault();
            handleRightRelease();
          }}
          onMouseLeave={(e) => {
            e.preventDefault();
            handleRightRelease();
          }}
        >
          <ChevronRight className="w-8 h-8" />
        </Button>
      </div>

      {/* Control Instructions */}
      <div className="text-center mt-4">
        <p className="text-cyan-400 text-sm opacity-60">
          Tap and hold to move
        </p>
      </div>
    </div>
  );
}
