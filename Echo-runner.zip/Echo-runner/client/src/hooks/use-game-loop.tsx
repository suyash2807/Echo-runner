import { useEffect, useRef, useCallback } from "react";

export function useGameLoop(
  updateFn: (deltaTime: number) => void,
  renderFn: () => void,
  isRunning: boolean
) {
  const requestRef = useRef<number>();
  const previousTimeRef = useRef<number>();
  const isRunningRef = useRef(isRunning);

  // Update the ref when isRunning changes
  useEffect(() => {
    isRunningRef.current = isRunning;
  }, [isRunning]);

  const animate = useCallback((time: number) => {
    if (!isRunningRef.current) {
      requestRef.current = undefined;
      return;
    }

    if (previousTimeRef.current !== undefined) {
      const deltaTime = time - previousTimeRef.current;
      
      // Call update function with delta time
      updateFn(deltaTime);
      
      // Call render function
      renderFn();
    }
    
    previousTimeRef.current = time;
    requestRef.current = requestAnimationFrame(animate);
  }, [updateFn, renderFn]);

  useEffect(() => {
    if (isRunning) {
      previousTimeRef.current = undefined;
      requestRef.current = requestAnimationFrame(animate);
    } else {
      if (requestRef.current) {
        cancelAnimationFrame(requestRef.current);
        requestRef.current = undefined;
      }
    }

    return () => {
      if (requestRef.current) {
        cancelAnimationFrame(requestRef.current);
      }
    };
  }, [isRunning, animate]);
}
