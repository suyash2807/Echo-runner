import { create } from "zustand";
import { subscribeWithSelector } from "zustand/middleware";

export type EchoGameState = "menu" | "playing" | "gameOver" | "store";

export interface Skin {
  id: string;
  name: string;
  playerColor: string;
  echoColor: string;
  price: number;
  unlocked: boolean;
}

interface EchoGameStore {
  gameState: EchoGameState;
  score: number;
  highScore: number;
  coins: number;
  currentSkin: string;
  skins: Skin[];
  
  // Actions
  startGame: () => void;
  endGame: () => void;
  restartGame: () => void;
  incrementScore: () => void;
  resetScore: () => void;
  openStore: () => void;
  closeStore: () => void;
  buySkin: (skinId: string) => boolean;
  selectSkin: (skinId: string) => void;
  addCoins: (amount: number) => void;
}

const STORAGE_KEY = "echo-runner-high-score";
const COINS_KEY = "echo-runner-coins";
const SKINS_KEY = "echo-runner-skins";
const CURRENT_SKIN_KEY = "echo-runner-current-skin";

// Default skins
const defaultSkins: Skin[] = [
  { id: "default", name: "Classic", playerColor: "#00ffff", echoColor: "#ff3366", price: 0, unlocked: true },
  { id: "fire", name: "Fire Runner", playerColor: "#ff4500", echoColor: "#ff8c00", price: 100, unlocked: false },
  { id: "nature", name: "Forest Spirit", playerColor: "#32cd32", echoColor: "#228b22", price: 150, unlocked: false },
  { id: "electric", name: "Lightning", playerColor: "#ffff00", echoColor: "#ffd700", price: 200, unlocked: false },
  { id: "ice", name: "Frost Walker", playerColor: "#87ceeb", echoColor: "#4169e1", price: 250, unlocked: false },
  { id: "void", name: "Void Master", playerColor: "#8a2be2", echoColor: "#4b0082", price: 300, unlocked: false }
];

// Load data from localStorage
const loadHighScore = (): number => {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved ? parseInt(saved, 10) : 0;
  } catch {
    return 0;
  }
};

const loadCoins = (): number => {
  try {
    const saved = localStorage.getItem(COINS_KEY);
    return saved ? parseInt(saved, 10) : 0;
  } catch {
    return 0;
  }
};

const loadSkins = (): Skin[] => {
  try {
    const saved = localStorage.getItem(SKINS_KEY);
    return saved ? JSON.parse(saved) : defaultSkins;
  } catch {
    return defaultSkins;
  }
};

const loadCurrentSkin = (): string => {
  try {
    const saved = localStorage.getItem(CURRENT_SKIN_KEY);
    return saved || "default";
  } catch {
    return "default";
  }
};

// Save data to localStorage
const saveHighScore = (score: number): void => {
  try {
    localStorage.setItem(STORAGE_KEY, score.toString());
  } catch {
    // Silently fail if localStorage is not available
  }
};

const saveCoins = (coins: number): void => {
  try {
    localStorage.setItem(COINS_KEY, coins.toString());
  } catch {
    // Silently fail if localStorage is not available
  }
};

const saveSkins = (skins: Skin[]): void => {
  try {
    localStorage.setItem(SKINS_KEY, JSON.stringify(skins));
  } catch {
    // Silently fail if localStorage is not available
  }
};

const saveCurrentSkin = (skinId: string): void => {
  try {
    localStorage.setItem(CURRENT_SKIN_KEY, skinId);
  } catch {
    // Silently fail if localStorage is not available
  }
};

export const useEchoGame = create<EchoGameStore>((set, get) => ({
  gameState: "menu",
  score: 0,
  highScore: loadHighScore(),
  coins: loadCoins(),
  currentSkin: loadCurrentSkin(),
  skins: loadSkins(),
  
  startGame: () => {
    console.log("Starting game...");
    set({
      gameState: "playing",
      score: 0
    });
  },
  
  endGame: () => {
    const { score, highScore, coins } = get();
    const newHighScore = Math.max(score, highScore);
    const coinsEarned = Math.floor(score / 10); // 1 coin per 10 points
    const newCoins = coins + coinsEarned;
    
    if (newHighScore > highScore) {
      saveHighScore(newHighScore);
    }
    saveCoins(newCoins);
    
    console.log("Game ended with score:", score, "Coins earned:", coinsEarned);
    set({
      gameState: "gameOver",
      highScore: newHighScore,
      coins: newCoins
    });
  },
  
  restartGame: () => {
    console.log("Restarting game...");
    set({
      gameState: "playing",
      score: 0
    });
  },
  
  incrementScore: () => {
    set((state) => ({
      score: state.score + 1
    }));
  },
  
  resetScore: () => {
    set({ score: 0 });
  },
  
  openStore: () => {
    set({ gameState: "store" });
  },
  
  closeStore: () => {
    set({ gameState: "menu" });
  },
  
  buySkin: (skinId: string) => {
    const { skins, coins } = get();
    const skin = skins.find(s => s.id === skinId);
    
    if (!skin || skin.unlocked || coins < skin.price) {
      return false;
    }
    
    const newSkins = skins.map(s => 
      s.id === skinId ? { ...s, unlocked: true } : s
    );
    const newCoins = coins - skin.price;
    
    saveSkins(newSkins);
    saveCoins(newCoins);
    
    set({
      skins: newSkins,
      coins: newCoins
    });
    
    return true;
  },
  
  selectSkin: (skinId: string) => {
    const { skins } = get();
    const skin = skins.find(s => s.id === skinId);
    
    if (skin && skin.unlocked) {
      saveCurrentSkin(skinId);
      set({ currentSkin: skinId });
    }
  },
  
  addCoins: (amount: number) => {
    const { coins } = get();
    const newCoins = coins + amount;
    saveCoins(newCoins);
    set({ coins: newCoins });
  }
}));
