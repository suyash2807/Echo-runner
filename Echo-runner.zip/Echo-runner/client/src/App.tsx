import { Suspense, useEffect } from "react";
import "@fontsource/inter";
import EchoRunner from "./components/EchoRunner";

function App() {
  return (
    <div style={{ width: '100vw', height: '100vh', position: 'relative', overflow: 'hidden' }}>
      <Suspense fallback={
        <div className="flex items-center justify-center w-full h-full bg-black text-white">
          <div className="text-xl">Loading Echo Runner...</div>
        </div>
      }>
        <EchoRunner />
      </Suspense>
    </div>
  );
}

export default App;
