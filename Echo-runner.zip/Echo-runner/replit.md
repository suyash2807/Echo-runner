# Echo Runner - Browser-based Game

## Overview

Echo Runner is a browser-based arcade game built with React, TypeScript, and Express.js. The application follows a client-server architecture with a minimal backend and a rich frontend gaming experience. The game features HTML5 Canvas-based graphics, real-time gameplay mechanics, and persistent high score tracking.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for development and production builds
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **State Management**: Zustand for global game state
- **UI Components**: Radix UI primitives with custom styling
- **Game Engine**: Custom HTML5 Canvas-based rendering with React hooks

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM (currently using in-memory storage)
- **Session Management**: Connect-pg-simple for PostgreSQL sessions
- **Development**: Hot reloading with Vite integration

### Build System
- **Frontend**: Vite with React plugin and TypeScript
- **Backend**: ESBuild for production bundling
- **Development**: TSX for TypeScript execution
- **Asset Handling**: Support for 3D models (GLTF/GLB) and audio files

## Key Components

### Game Logic
- **EchoRunner**: Main game component managing canvas and game state
- **GameCanvas**: HTML5 Canvas renderer with collision detection
- **GameUI**: Overlay interface for menus, scores, and controls
- **MobileControls**: Touch-friendly controls for mobile devices

### State Management
- **useEchoGame**: Game state (menu/playing/gameOver), scoring, difficulty
- **useAudio**: Sound management with mute/unmute functionality
- **useGame**: Generic game phase management

### Storage Layer
- **MemStorage**: In-memory implementation of storage interface
- **IStorage**: Interface defining CRUD operations for users
- **Schema**: Drizzle schema definitions for PostgreSQL tables

### UI System
- **Radix UI**: Accessible component primitives
- **Custom Components**: Game-specific UI built on Radix foundation
- **Responsive Design**: Mobile-first approach with touch controls

## Data Flow

### Game State Flow
1. **Menu State**: Player sees welcome screen with instructions
2. **Playing State**: Active gameplay with real-time updates
3. **Game Over State**: Score display and restart options
4. **Score Persistence**: High scores saved to localStorage

### Input Handling
1. **Keyboard Events**: Arrow keys for player movement
2. **Touch Events**: Mobile controls simulate keyboard events
3. **State Updates**: Input drives player position and game logic
4. **Collision Detection**: Real-time checking against echo trails - touching any echo ends the game

### Audio System
1. **Sound Loading**: Audio files preloaded on component mount
2. **Mute State**: Global mute toggle affects all sound playback
3. **Sound Effects**: Hit sounds triggered on collision events

## External Dependencies

### Core Libraries
- **React Ecosystem**: React, ReactDOM, React Query for state management
- **TypeScript**: Full type safety across frontend and backend
- **Express.js**: Minimal REST API server
- **Drizzle ORM**: Type-safe database operations

### UI/UX Libraries
- **Radix UI**: Complete set of accessible component primitives
- **Tailwind CSS**: Utility-first CSS framework
- **Lucide React**: Icon library
- **Class Variance Authority**: Component variant management

### Development Tools
- **Vite**: Fast build tool with HMR
- **ESBuild**: Production bundling
- **TSX**: TypeScript execution for development

### Database & Storage
- **@neondatabase/serverless**: PostgreSQL driver
- **Connect-pg-simple**: Session storage
- **LocalStorage**: Client-side high score persistence

## Deployment Strategy

### Development Mode
- **Frontend**: Vite dev server with hot reloading
- **Backend**: Express server with Vite middleware integration
- **Database**: In-memory storage for rapid development

### Production Build
1. **Frontend Build**: Vite builds React app to `dist/public`
2. **Backend Build**: ESBuild bundles server to `dist/index.js`
3. **Static Serving**: Express serves frontend assets
4. **Database**: PostgreSQL with Drizzle migrations

### Environment Configuration
- **DATABASE_URL**: PostgreSQL connection string
- **NODE_ENV**: Environment detection (development/production)
- **Build Scripts**: Separate dev, build, and start commands

### Asset Management
- **Fonts**: Inter font family loaded via @fontsource
- **Audio**: MP3/OGG/WAV files served as static assets
- **3D Models**: GLTF/GLB support for future 3D features

The application is designed for easy deployment to platforms like Replit, with automatic database provisioning and environment variable management.